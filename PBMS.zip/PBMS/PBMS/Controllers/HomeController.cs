﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBMS.Models;

namespace PBMS.Controllers
{
    public class HomeController : Controller
    {
        PBMSEntities mycontext = new PBMSEntities();
        //
        // GET: /Home/

        public ActionResult Index()
        {
           // var business = mycontext.Set<Business>().Where(u => u.UserName == Session["UserName"].ToString());
            var business = mycontext.Set<Business>().Where(u => u.UserName == "admin");
            return View(business);
        }
        [HttpPost]
        public ActionResult GetUserData()
        {
            //string UserName = Session["UserName"].ToString();
            string UserName = "admin";
            var user=mycontext.Set<User>().Where(u => u.UserName == UserName).FirstOrDefault();
            return Json(user,JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetUserStyle()
        {
            var style = mycontext.Set<Style>().Where(u => u.UserName == "admin").FirstOrDefault();
            return Json(style, JsonRequestBehavior.AllowGet);
        }
    }
}

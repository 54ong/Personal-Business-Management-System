﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Mvc.Html;
using PBMS.Models;
using PBMS.Class;

namespace PBMS.Controllers
{
    public class LoginController : Controller
    {
        PBMSEntities mycontext = new PBMSEntities();

        //用该类接受登录页面传输过来的数据
        public static class UserData
        {
            public static string UserName;
            public static string Password;
            public static string Tel;
            public static string AuthCode;
        } 
        //
        // GET: /Login/

        public ActionResult LoginIndex()
        {
           
            return View();
        }

        public ActionResult RegisterIndex()
        {
            return View();
        }

        public string GetAuthCode()
        {
            Random random = new Random();
            UserData.AuthCode=random.Next(11111, 99999).ToString();
            SMS_Message_Sender sms = new SMS_Message_Sender();
            sms.Tel = Request["Tel"].ToString();
            sms.Content = "您的验证码是" + UserData.AuthCode;
            sms.Send(sms);
            return "ok";
        }

        public string UserLogin()
        {
             UserData.UserName=Request["UserName"];
             UserData.Password=Request["Password"];
             UserData.Tel=Request["Tel"];
             var user=mycontext.Set<User>().Find(UserData.UserName);
             if (user == null)
             {
                 return "no_user";
             }
             else if (UserData.Password != user.Password || UserData.Tel != user.Tel)
             {
                 return "wrong_password_or_tel";
             }
             else if(UserData.AuthCode!=Request["code"])
             {
                 return "wrong_code";
             }
            else
             {
                 Session["UserName"] = UserData.UserName;
                 return "success";
                
             }
           
        }

        public string UserRegister()
        {
            UserData.UserName = Request["UserName"];
            UserData.Password = Request["Password"];
            UserData.Tel = Request["Tel"];
            var user = mycontext.Set<User>().Find(UserData.UserName);
            if (user != null)
            {
                return "have_user";
            }
            else if ( mycontext.Set<User>().Where(u=>u.Tel==UserData.Tel).FirstOrDefault()!=null)
            {
                return "have_tel";
            }
            else if (UserData.AuthCode != Request["code"])
            {
                return "wrong_code";
            }
            else
            {
                Models.User NewUser=new Models.User(){
                UserName=UserData.UserName,
                Password=UserData.Password,
                Tel=UserData.Tel
                
                };
                mycontext.Set<User>().Add(NewUser);
                return "success";

            }
            
        }

    }
}

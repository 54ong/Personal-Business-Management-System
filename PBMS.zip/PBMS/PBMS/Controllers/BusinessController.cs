﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBMS.Models;
using System.Data.Entity.Migrations;

namespace PBMS.Controllers
{
    public class BusinessController : Controller
    {
        
        PBMSEntities mycontext = new PBMSEntities();
        //
        // GET: /Business/

        public ActionResult Index()
        {
            Session["UserName"] = "admin";
           
            return View();
           
        }
       
            public ActionResult ShowData(int page, int pagesize)
        {
          
            var list = mycontext.Set<Business>().OrderBy(u => u.ID).Skip((page - 1) * pagesize).Take(pagesize);

            return View(list);
            
        }
        public ActionResult SearchData(int page,int pagesize,string priority,DateTime enddate,string isalert,string keyword)
            {
                
                bool Isalert;
                if (isalert == "1") Isalert = true;
                else Isalert = false;
                var list = mycontext.Set<Business>().OrderBy(u => u.ID).Where(u => u.Priority == priority).Where(u => u.EndDate <= enddate).Where(u => u.Text.Contains(keyword)).Where( u=>u.AlertTime.HasValue==Isalert).Skip((page - 1) * pagesize).Take(pagesize);
                return View(list);
            }
        public ActionResult AddorUpdateBusiness(Business business)
        {
            //business.UserName = Session["UserName"].ToString();
            business.UserName = "admin";
            var business_exist = mycontext.Set<Business>().Where(u => u.Text == business.Text).FirstOrDefault();
            if (business_exist == null)
            {
                mycontext.Set<Business>().Add(business);
                var user = mycontext.Set<User>().Where(u => u.UserName == Session["UserName"].ToString()).FirstOrDefault();
                user.Publish_Number += 1;
                mycontext.Set<User>().AddOrUpdate(u => u.UserName, user);
            }
            else
                mycontext.Set<Business>().AddOrUpdate(u => u.Text, business);
            mycontext.SaveChanges();
            return View("Index");
        }
        public ActionResult Delete()
        {
            int id = int.Parse(Request["Id"]);
            var business = mycontext.Set<Business>().Where(u => u.ID == id).FirstOrDefault();
            mycontext.Set<Business>().Remove(business);
            mycontext.SaveChanges();
            return View("Index");
        }
        [HttpPost]
        public ActionResult GetBusinessInfo()
        {
            int id = int.Parse(Request["Id"]);
            var business = mycontext.Set<Business>().Where(u => u.ID == id).FirstOrDefault();
            return Json(business, JsonRequestBehavior.AllowGet);
        }
        public ActionResult JobFinish()
        {
            int id = int.Parse(Request["Id"]);
            var business = mycontext.Set<Business>().Where(u => u.ID == 
                id).FirstOrDefault();
            mycontext.Set<Business>().Remove(business);
            mycontext.SaveChanges();
            var user = mycontext.Set<User>().Where(u => u.UserName == Session["UserName"].ToString()).FirstOrDefault();
            user.Money += 10;
            user.Complete_Number += 1;
            mycontext.Set<User>().AddOrUpdate(u => u.UserName, user);
            return View("Index");
        }
        public ActionResult GetUserStyle()
        {
            var style = mycontext.Set<Style>().Where(u => u.UserName == "admin");
            return Json(style, JsonRequestBehavior.AllowGet);
        }
    }
}

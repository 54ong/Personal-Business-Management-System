﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBMS.Models;
using PBMS.Class;
using System.Data.Entity.Migrations;

namespace PBMS.Controllers
{
    public class PersonalCenterController : Controller
    {
        PBMSEntities mycontext = new PBMSEntities();
        //
        // GET: /PersonalCenter/

        public ActionResult Index()
        {
            Session["UserName"] = "admin";
            Session["Password"] = "admin";
            return View();
        }
        public ActionResult GetUserInfo()
        {
            string UserName = Session["UserName"].ToString();
            var user=mycontext.Set<User>().Where(u => u.UserName == UserName).FirstOrDefault();
            return Json(user, JsonRequestBehavior.AllowGet);
        }
        public ActionResult UpdateUserInfo(User user)
        {
            string user_tel=HttpContext.Request.Form["user_tel"].ToString(); 
            var user_name_exist = mycontext.Set<User>().Where(u => u.UserName == user.UserName).FirstOrDefault();
            var user_tel_exist = mycontext.Set<User>().Where(u => u.Tel==user.Tel).FirstOrDefault();
            if (user_name_exist != null && user.UserName != Session["UserName"].ToString())
            //说明你刚好改成了其他用户的昵称了
            {
                Response.Write("<script>alert('该昵称已被占用')</script>");
                return View("Index");
            }
            else if(user_tel_exist!=null&&user.Tel!=user_tel) //说明你刚好改成了其他用户的手机号了
            {
                Response.Write("<script>alert('该手机号已被注册')</script>");
                return View("Index");
            }
            else//通过验证可以进行相关数据库操作了
            {
                if(user_tel_exist==null)//更改成了未被注册的手机号码(需要进行验证)
                {
                    SMS_Message_Sender sms = new SMS_Message_Sender();
                    sms.Tel=user.Tel;
                    sms.Content=new Random().Next(11111,99999).ToString();
                    sms.Send(sms);
                    Response.Write("<script>alert('请回复您收到的验证码，工作人员将在三到五个工作日内进行验证并更改您绑定的手机号')</script>");
                    
                }
                
                string user_name = Session["UserName"].ToString();
                if(user.UserName==user_name)
                    
                    mycontext.Set<User>().AddOrUpdate(u=>u.UserName,user);
                else
                    mycontext.Set<User>().AddOrUpdate(u => u.Tel, user);
                mycontext.SaveChanges();
                Response.Write("<script>alert('操作成功')</script>");
                return View("Index");
            }
                
        }
        public void Data_Synchronous(User user,User user_last_version)
    {
                user.Tel = user_last_version.Tel;
                user.Complete_Number = user_last_version.Complete_Number;
                user.Last_Sign_In_Date = user_last_version.Last_Sign_In_Date;
                user.Library = user_last_version.Library;
                user.Money = user_last_version.Money;
                user.Publish_Number = user_last_version.Publish_Number;
                user.Sign_In_Noofdays = user_last_version.Sign_In_Noofdays;
                //user.Style = user_last_version.Style;
    }
        public ActionResult Sign_In(string last_sign_in_date,int Isrunning)
        {
            string UserName = Session["UserName"].ToString();
            var user=mycontext.Set<User>().Where(u => u.UserName == UserName).FirstOrDefault();
            user.Sign_In_Noofdays += 1;
            user.Last_Sign_In_Date = last_sign_in_date;
            user.Money += 10;
            if (Isrunning != 1)
                user.Sign_In_Noofdays = 1;
            mycontext.Set<User>().AddOrUpdate(u => u.UserName, user);
            mycontext.SaveChanges();
            return View("Index");
        }
        public ActionResult Reward()
        {
            string UserName = Session["UserName"].ToString();
            var user = mycontext.Set<User>().Where(u => u.UserName == UserName).FirstOrDefault();
            user.Money += 30;
            user.Publish_Number += 1;
            user.Sign_In_Noofdays += 1;
            mycontext.Set<User>().AddOrUpdate(u => u.UserName, user);
            mycontext.SaveChanges();
            return View("Index");
        }
    }
}

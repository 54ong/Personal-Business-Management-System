﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBMS.Models;
using PBMS.Class;
using System.Data.Entity.Migrations;

namespace PBMS.Controllers
{
    public class ShopController : Controller
    {
        PBMSEntities mycontext = new PBMSEntities();
        //
        // GET: /Shop/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Purchase()
        {
            string item = Request["Item"].ToString();
            int price = int.Parse(Request["Price"]);
            var user = mycontext.Set<User>().Where(u => u.UserName == "admin").FirstOrDefault();
            if(user.Money<price)
            {
                string result = "你钱不够";
                return Json(result, JsonRequestBehavior.AllowGet);
            }
            else
            {
                user.Money -= price;
                user.Library += item;
                mycontext.Set<User>().AddOrUpdate(u => u.UserName, user);
                mycontext.SaveChanges();
                string result = "成交";
                return Json(result, JsonRequestBehavior.AllowGet);
            }

        }
    }
}

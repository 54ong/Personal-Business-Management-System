﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PBMS.Models;
using PBMS.Class;
using System.Data.Entity.Migrations;

namespace PBMS.Controllers
{
    public class StyleController : Controller
    {
        PBMSEntities mycontext = new PBMSEntities();
        //
        // GET: /Style/

        public ActionResult Index()
        { 
            return View();
        }
       public ActionResult GetUserStyle()
        {
            var style = mycontext.Set<Style>().Where(u => u.UserName == "admin").FirstOrDefault(); 
            return Json(style, JsonRequestBehavior.AllowGet);
        }

    }
}

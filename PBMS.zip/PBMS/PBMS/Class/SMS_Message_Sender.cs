﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;

namespace PBMS.Class
{
    public class SMS_Message_Sender
    {
         //Note:接口发送触发短信时，您可以把短信内容提供给客服绑定短信模板，绑定后24小时即时发送。未绑定模板的短信21点以后提交，隔天才能收到。

        private string Sms_Url = "http://utf8.sms.webchinese.cn/";//发送短信平台网址
        private string UserId="54ONG";//注册的SMS平台的账号ID  
        private string Key = "36999cf058b772ccfb58";//注册的SMS平台的接口密匙  
        public string Tel;//手机号码  
        public string Content;// 发送的内容  
        public DateTime AlertTime;//发送的时间

        /// <summary>
        /// 根据该类的属性来发送短信
        /// </summary>
        /// <param name="url"></param>
        /// <returns></returns>
        public string Send(SMS_Message_Sender sms)
        {
            
            
            string url=sms.Sms_Url+"?Uid="+sms.UserId+"&Key="+sms.Key+"&smsMob="+sms.Tel+"&smsText="+sms.Content;
            string strRet = null;//接受返回值
            
                string targeturl = url.Trim().ToString();
                try
                {
                    //根据特定url地址创建webRequest类的实例
                    HttpWebRequest hr = (HttpWebRequest)WebRequest.Create(targeturl);
                    hr.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)";
                    hr.Method = "GET";
                    //设定停止请求的时间
                    hr.Timeout = 30 * 60 * 1000;
                    //用WebResponse对象得到返回对象，用stream对象接受返回对象解析的stream，再用streamReader对象读取该stream
                    WebResponse hs = hr.GetResponse();
                    Stream sr = hs.GetResponseStream();
                    StreamReader ser = new StreamReader(sr, Encoding.Default);
                    strRet = ser.ReadToEnd();
                }
                catch (Exception)
                {

                    strRet = null;
                }
                return strRet;
            }
        }
    
    }
